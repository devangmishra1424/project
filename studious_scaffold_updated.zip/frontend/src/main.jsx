import React from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import './styles.css'
import Login from './pages/Login'
import Signup from './pages/Signup'
import Dashboard from './pages/Dashboard'
import Files from './pages/Files'
import Links from './pages/Links'
import ProtectedRoute from './components/ProtectedRoute'

function App(){
  const token = localStorage.getItem('token');
  return (
    <BrowserRouter>
      <Routes>
        <Route path='/' element={token ? <Navigate to='/dashboard'/> : <Navigate to='/login'/>} />
        <Route path='/login' element={<Login/>} />
        <Route path='/signup' element={<Signup/>} />
        <Route path='/dashboard' element={<ProtectedRoute><Dashboard/></ProtectedRoute>} />
        <Route path='/files' element={<ProtectedRoute><Files/></ProtectedRoute>} />
        <Route path='/links' element={<ProtectedRoute><Links/></ProtectedRoute>} />
      </Routes>
    </BrowserRouter>
  )
}

createRoot(document.getElementById('root')).render(<App />)
