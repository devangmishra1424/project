import React, {useState, useEffect} from 'react';
import API from '../api';

export default function Files(){
  const [files,setFiles]=useState([]);
  const [name,setName]=useState('');
  const [fileInput,setFileInput]=useState(null);
  const [msg,setMsg]=useState('');

  useEffect(()=>{ load(); },[]);
  async function load(){ const res=await API.get('/files'); setFiles(res.data); }

  function onPick(e){ const f = e.target.files[0]; if(!f) return; setFileInput(f); setName(f.name); }

  async function upload(e){
    e.preventDefault();
    if(!fileInput) return setMsg('Pick a file');
    const reader = new FileReader();
    reader.onload = async () => {
      const dataUrl = reader.result;
      await API.post('/files', { name, mimeType: fileInput.type, dataUrl });
      setMsg('Uploaded'); setFileInput(null); setName(''); load();
    };
    reader.readAsDataURL(fileInput);
  }

  return (
    <div style={{padding:20}}>
      <h2>Files</h2>
      <div style={{display:'flex',gap:20}}>
        <div style={{flex:1}} className='card'>
          <h3>Upload file</h3>
          <form onSubmit={upload}>
            <input type='file' onChange={onPick} />
            <div style={{marginTop:8}}><button className='btn' type='submit'>Upload</button></div>
            {msg && <div style={{marginTop:8}}>{msg}</div>}
          </form>
        </div>
        <div style={{width:420}} className='card'>
          <h3>Your files</h3>
          <ul>
            {files.map(f=> <li key={f._id}><strong>{f.name}</strong> <button className='btn' style={{marginLeft:8}} onClick={()=>{ window.open(f.dataUrl); }}>Open</button></li>)}
          </ul>
        </div>
      </div>
    </div>
  )
}
