import React, {useEffect, useState} from 'react'
import API from '../api'
import { useNavigate } from 'react-router-dom'

export default function Dashboard(){
  const [profile,setProfile]=useState(null);
  const [goals,setGoals]=useState([]);
  const [title,setTitle]=useState('')
  const [files,setFiles]=useState([]);
  const [links,setLinks]=useState([]);
  const nav = useNavigate()

  useEffect(()=>{
    async function load(){ 
      try{
        const p = await API.get('/profile'); setProfile(p.data);
        const g = await API.get('/goals'); setGoals(g.data);
        const f = await API.get('/files'); setFiles(f.data);
        const l = await API.get('/links'); setLinks(l.data);
      }catch(err){ console.error(err); }
    }
    load();
  },[]);

  async function addGoal(e){
    e.preventDefault();
    if(!title) return;
    await API.post('/goals',{title});
    const g = await API.get('/goals'); setGoals(g.data);
    setTitle('');
  }

  async function attachFile(goalId, fileId){
    await API.post('/goals', { _id: goalId, fileId });
    const g = await API.get('/goals'); setGoals(g.data);
  }

  async function attachLink(goalId, linkId){
    await API.post('/goals', { _id: goalId, linkId });
    const g = await API.get('/goals'); setGoals(g.data);
  }

  function submitGoal(goal){
    // If both file and link exist, open them: file (dataUrl) then link
    if(goal.fileId && goal.fileId.dataUrl) window.open(goal.fileId.dataUrl);
    if(goal.linkId && goal.linkId.url) window.open(goal.linkId.url, '_blank');
  }

  return (
    <div style={{padding:20}}>
      <div className='nav'><div><strong>Studious</strong></div><div>Welcome</div></div>
      <div style={{display:'grid',gridTemplateColumns:'1fr 320px', gap:20, marginTop:20}}>
        <div>
          <div className='card'>
            <h3>Today's summary</h3>
            <p>Welcome to your daily hub. Classes, goals, files and important links show up here.</p>
          </div>

          <div style={{marginTop:16}} className='card'>
            <h4>Goals</h4>
            <form onSubmit={addGoal}>
              <input className='input' placeholder='New goal title' value={title} onChange={e=>setTitle(e.target.value)} />
              <div style={{marginTop:8}}><button className='btn' type='submit'>Add Goal</button></div>
            </form>
            <ul style={{marginTop:12}}>
              {goals.map(g=> <li key={g._id} style={{marginBottom:10}}>
                <div><strong>{g.title}</strong></div>
                <div style={{marginTop:6}}>
                  {g.fileId ? <span style={{marginRight:8}}>📎 {g.fileId.name}</span> : null}
                  {g.linkId ? <span style={{marginRight:8}}>🔗 {g.linkId.title}</span> : null}
                  {g.fileId && g.linkId ? <button className='btn' style={{marginLeft:8}} onClick={()=>submitGoal(g)}>Submit</button> : null}
                </div>
                <div style={{marginTop:6}}>
                  <select onChange={e=> attachFile(g._id, e.target.value)} defaultValue=''>
                    <option value=''>Attach file...</option>
                    {files.map(f=> <option key={f._id} value={f._id}>{f.name}</option>)}
                  </select>
                  <select onChange={e=> attachLink(g._id, e.target.value)} defaultValue='' style={{marginLeft:8}}>
                    <option value=''>Attach link...</option>
                    {links.map(l=> <option key={l._id} value={l._id}>{l.title}</option>)}
                  </select>
                </div>
              </li>)}
            </ul>
          </div>
        </div>

        <div>
          <div className='card'>
            <h4>Quick actions</h4>
            <button className='btn' style={{width:'100%'}} onClick={()=>nav('/files')}>Open Files</button>
            <div style={{height:12}}/>
            <button className='btn' style={{width:'100%'}} onClick={()=>nav('/links')}>Open Links</button>
          </div>
        </div>
      </div>
    </div>
  )
}
