import React, {useState, useEffect} from 'react';
import API from '../api';

export default function Links(){
  const [links,setLinks]=useState([]);
  const [title,setTitle]=useState('');
  const [url,setUrl]=useState('');

  useEffect(()=>{ load(); },[]);
  async function load(){ const res=await API.get('/links'); setLinks(res.data); }

  async function add(e){
    e.preventDefault();
    if(!title || !url) return;
    await API.post('/links', { title, url });
    setTitle(''); setUrl(''); load();
  }

  return (
    <div style={{padding:20}}>
      <h2>Important Links</h2>
      <div style={{display:'flex',gap:20}}>
        <div style={{flex:1}} className='card'>
          <h3>Add link</h3>
          <form onSubmit={add}>
            <input className='input' placeholder='Title' value={title} onChange={e=>setTitle(e.target.value)} />
            <div style={{marginTop:8}}><input className='input' placeholder='https://...' value={url} onChange={e=>setUrl(e.target.value)} /></div>
            <div style={{marginTop:8}}><button className='btn' type='submit'>Add Link</button></div>
          </form>
        </div>
        <div style={{width:420}} className='card'>
          <h3>Your links</h3>
          <ul>
            {links.map(l=> <li key={l._id}><strong>{l.title}</strong> <a href={l.url} target='_blank' rel='noreferrer'>Open</a></li>)}
          </ul>
        </div>
      </div>
    </div>
  )
}
