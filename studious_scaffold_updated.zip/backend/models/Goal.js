const mongoose = require('mongoose');
const GoalSchema = new mongoose.Schema({
  userId: {type: mongoose.Schema.Types.ObjectId, ref:'User', required:true},
  title: String,
  description: String,
  dueDate: Date,
  completed: {type:Boolean, default:false},
  fileId: {type: mongoose.Schema.Types.ObjectId, ref:'File'},
  linkId: {type: mongoose.Schema.Types.ObjectId, ref:'Link'},
  createdAt: {type:Date, default: Date.now}
});
module.exports = mongoose.model('Goal', GoalSchema);
