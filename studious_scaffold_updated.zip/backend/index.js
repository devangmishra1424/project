require('dotenv').config();
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const authRoutes = require('./routes/auth');
const apiRoutes = require('./routes/api');
const filesRoutes = require('./routes/files');
const linksRoutes = require('./routes/links');

const app = express();
app.use(cors());
app.use(express.json({limit: '10mb'}));

const PORT = process.env.PORT || 4000;
const MONGO = process.env.MONGO_URI || 'mongodb://localhost:27017/studious';

mongoose.connect(MONGO, {useNewUrlParser:true, useUnifiedTopology:true})
  .then(()=> console.log('MongoDB connected'))
  .catch(err=> console.error('MongoDB connection error:', err));

app.use('/api/auth', authRoutes);
app.use('/api', apiRoutes);
app.use('/api/files', filesRoutes);
app.use('/api/links', linksRoutes);

app.get('/', (req,res)=> res.json({ok:true, msg:'Studious backend running'}));

app.listen(PORT, ()=> console.log(`Server running on port ${PORT}`));
