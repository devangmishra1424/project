const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Link = require('../models/Link');

router.post('/', auth, async (req,res)=>{
  try{
    const {title, url, tags} = req.body;
    if(!title || !url) return res.status(400).json({msg:'Missing fields'});
    const l = await Link.create({userId: req.user.id, title, url, tags: tags||[]});
    res.json(l);
  }catch(err){ console.error(err); res.status(500).json({msg:'err'});}
});

router.get('/', auth, async (req,res)=>{
  try{
    const links = await Link.find({userId: req.user.id}).sort({createdAt:-1});
    res.json(links);
  }catch(err){ console.error(err); res.status(500).json({msg:'err'});}
});

module.exports = router;
