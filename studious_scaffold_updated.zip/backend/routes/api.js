const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Goal = require('../models/Goal');

// Protected route: get profile
router.get('/profile', auth, async (req,res)=>{
  const uid = req.user.id;
  res.json({userId: uid});
});

// Goals CRUD (with optional fileId/linkId)
router.post('/goals', auth, async (req,res)=>{
  try{
    const body = req.body || {};
    // If body contains _id, treat as update for linking
    if(body._id){
      const id = body._id;
      const update = {...body};
      delete update._id;
      const g = await Goal.findOneAndUpdate({_id:id, userId: req.user.id}, update, {new:true});
      return res.json(g);
    }
    const g = await Goal.create({...body, userId: req.user.id});
    res.json(g);
  }catch(err){ console.error(err); res.status(500).json({msg:'err'});}
});

router.get('/goals', auth, async (req,res)=>{
  try{
    const gs = await Goal.find({userId: req.user.id}).populate('fileId linkId');
    res.json(gs);
  }catch(err){ console.error(err); res.status(500).json({msg:'err'});}
});

module.exports = router;
