const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const File = require('../models/File');

// Upload metadata + base64 data URL (dev). body: {name, mimeType, dataUrl}
router.post('/', auth, async (req,res)=>{
  try{
    const {name, mimeType, dataUrl} = req.body;
    if(!name) return res.status(400).json({msg:'Missing name'});
    const f = await File.create({userId: req.user.id, name, mimeType, dataUrl});
    res.json(f);
  }catch(err){ console.error(err); res.status(500).json({msg:'err'});}
});

// List user's files
router.get('/', auth, async (req,res)=>{
  try{
    const files = await File.find({userId: req.user.id}).sort({createdAt:-1});
    res.json(files);
  }catch(err){ console.error(err); res.status(500).json({msg:'err'});}
});

module.exports = router;
